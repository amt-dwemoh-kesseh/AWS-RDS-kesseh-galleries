import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import multer from 'multer';
import AWS from 'aws-sdk';
import { v4 as uuidv4 } from 'uuid';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import prisma from './lib/prisma.js'; // ✅ Replaces custom database logic

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = process.env.PORT || 3001;
const ENV = process.env.NODE_ENV || 'development';

const BUCKET_NAME = process.env.S3_BUCKET_NAME;
const REGION = process.env.AWS_REGION;

const s3 = new AWS.S3({ region: REGION });

app.use(helmet({
  crossOriginEmbedderPolicy: false,
  contentSecurityPolicy: false
}));

app.use(cors({
  origin: ENV === 'production' ? true : 'http://localhost:5173',
  credentials: true
}));

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

const DIST_PATH = path.join(__dirname, '../dist');
app.use(express.static(DIST_PATH, { maxAge: '1y', etag: false }));

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) cb(null, true);
    else cb(new Error('Only image files are allowed'), false);
  }
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Upload image
app.post('/api/upload', upload.single('image'), async (req, res) => {
  try {
    if (!req.file) return res.status(400).json({ error: 'No file provided' });

    const { description = '' } = req.body;
    const fileExtension = path.extname(req.file.originalname);
    const fileName = `${uuidv4()}${fileExtension}`;
    const key = `images/${fileName}`;

    const result = await s3.upload({
      Bucket: BUCKET_NAME,
      Key: key,
      Body: req.file.buffer,
      ContentType: req.file.mimetype,
      Metadata: {
        originalName: req.file.originalname,
        uploadedAt: new Date().toISOString()
      }
    }).promise();

    const publicUrl = `https://${BUCKET_NAME}.s3.${REGION}.amazonaws.com/${key}`;

    const imageRecord = await prisma.image.create({
      data: {
        url: publicUrl,
        description
      }
    });

    res.json({
      success: true,
      url: publicUrl,
      key: result.Key,
      id: imageRecord.id,
      description: imageRecord.description
    });
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ error: 'Failed to upload image', details: error.message });
  }
});

// Get paginated images
app.get('/api/images', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 12;

    const images = await prisma.image.findMany({
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { createdAt: 'desc' }
    });

    const totalCount = await prisma.image.count();
    const totalPages = Math.ceil(totalCount / limit);

    res.json({
      images,
      totalCount,
      totalPages,
      currentPage: page,
      hasMore: page < totalPages
    });
  } catch (error) {
    console.error('Get images error:', error);
    res.status(500).json({ error: 'Failed to fetch images', details: error.message });
  }
});

// Delete image by S3 key
app.delete('/api/images/:key(*)', async (req, res) => {
  try {
    const key = decodeURIComponent(req.params.key);

    const deletedImage = await prisma.image.findFirst({
      where: { url: { contains: key } }
    });

    if (!deletedImage) return res.status(404).json({ error: 'Image not found in DB' });

    await prisma.image.delete({ where: { id: deletedImage.id } });
    await s3.deleteObject({ Bucket: BUCKET_NAME, Key: key }).promise();

    res.json({ success: true, message: 'Image deleted successfully' });
  } catch (error) {
    console.error('Delete error:', error);
    res.status(500).json({ error: 'Failed to delete image', details: error.message });
  }
});

// Get image metadata
app.get('/api/images/:key(*)/metadata', async (req, res) => {
  try {
    const key = decodeURIComponent(req.params.key);

    const image = await prisma.image.findFirst({
      where: { url: { contains: key } }
    });

    if (!image) return res.status(404).json({ error: 'Image not found' });

    res.json(image);
  } catch (error) {
    console.error('Metadata error:', error);
    res.status(500).json({ error: 'Failed to get image metadata', details: error.message });
  }
});

// Update image description
app.put('/api/images/:id/description', async (req, res) => {
  try {
    const { id } = req.params;
    const { description } = req.body;

    const updated = await prisma.image.update({
      where: { id: parseInt(id) },
      data: { description }
    });

    res.json({ success: true, image: updated });
  } catch (error) {
    console.error('Update error:', error);
    res.status(500).json({ error: 'Failed to update description', details: error.message });
  }
});

// Catch-all route to serve index.html
app.get('*', (req, res) => {
  res.sendFile(path.join(DIST_PATH, 'index.html'));
});

// Global error handler
app.use((error, req, res, next) => {
  console.error('Server error:', error);
  if (error instanceof multer.MulterError && error.code === 'LIMIT_FILE_SIZE') {
    return res.status(400).json({ error: 'File too large. Max size is 10MB.' });
  }
  res.status(500).json({ error: 'Internal server error', details: ENV === 'development' ? error.message : undefined });
});

const INDEX_FILE = path.join(DIST_PATH, 'index.html');
try {
  const html = fs.readFileSync(INDEX_FILE, 'utf-8');
  console.log('📄 index.html content loaded');
} catch (err) {
  console.error('❌ Failed to read index.html:', err);
}

app.listen(PORT, () => {
  console.log(`🚀 Kesseh Galleries server running on port ${PORT}`);
  console.log(`📊 Environment: ${ENV}`);
  console.log(`🪣 S3 Bucket: ${BUCKET_NAME}`);
  console.log(`📁 Serving frontend from: ${DIST_PATH}`);
});
