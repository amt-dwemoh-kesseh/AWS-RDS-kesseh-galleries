// server/routes/images.ts
import express from 'express';
import multer from 'multer';
import prisma from '../lib/prisma';
import { uploadToS3 } from '../utils/s3';

const router = express.Router();
const upload = multer(); // uses memory storage

// Upload image
router.post('/images', upload.single('file'), async (req, res) => {
  try {
    const file = req.file;
    const { description } = req.body;

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const s3Response = await uploadToS3(file);

    const newImage = await prisma.image.create({
      data: {
        url: s3Response.url,
        description,
      },
    });

    res.status(201).json(newImage);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Image upload failed' });
  }
});

// Get paginated images
router.get('/images', async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const perPage = 10;

  try {
    const images = await prisma.image.findMany({
      skip: (page - 1) * perPage,
      take: perPage,
      orderBy: { createdAt: 'desc' },
    });

    const total = await prisma.image.count();

    res.json({
      data: images,
      pagination: {
        total,
        page,
        perPage,
        totalPages: Math.ceil(total / perPage),
      },
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error fetching images' });
  }
});

export default router;
